using System.Collections;
using UnityEngine;

public class CarSpawner : MonoBehaviour
{
    [Header("�ڵ��� ������")]
    public GameObject carPrefab;

    [Header("����")]
    public float spawnY = 1f;                // ���� ����
    public float spawnIntervalMin = 3f;      // �ּ� ���� ����
    public float spawnIntervalMax = 6f;      // �ִ� ���� ����

    private void Start()
    {
        StartCoroutine(SpawnCars());
    }

    private IEnumerator SpawnCars()
    {
        while (true)
        {
            SpawnCar();

            // ���� ���� ����
            float interval = Random.Range(spawnIntervalMin, spawnIntervalMax);
            yield return new WaitForSeconds(interval);
        }
    }

    private void SpawnCar()
    {
        if (carPrefab == null) return;

        Vector3 spawnPos = new Vector3(transform.position.x, spawnY, transform.position.z);

        GameObject car = Instantiate(carPrefab, spawnPos, carPrefab.transform.rotation);

        car.transform.localScale = carPrefab.transform.localScale;

        car.transform.SetParent(transform, true); // true = worldPositionStays
    }

}
