using UnityEngine;

public class CarMover : MonoBehaviour
{
    [Header("�̵� �Ӽ�")]
    public float speed = 5f;         // �̵� �ӵ�
    public float moveDistance = 40f; // �̵��� �ִ� �Ÿ�

    private Vector3 startPos;        

    private void Start()
    {
        startPos = transform.position;
    }

    private void Update()
    {
        // ������ �̵� (transform.forward ����)
        transform.Translate(Vector3.forward * speed * Time.deltaTime);

        float traveled = Vector3.Distance(startPos, transform.position);
        if (traveled >= moveDistance)
        {
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("CarBreaker"))
        {
            Destroy(gameObject);
        }
    }
}
