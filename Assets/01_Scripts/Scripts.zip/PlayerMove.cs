using System.Collections;
using UnityEngine;
using UnityEngine.InputSystem;
using DG.Tweening;

public class PlayerMove : MonoBehaviour
{
    public float jumpPower = 1f;      // ���� ����
    public float duration = 0.3f;     // ���� �ִϸ��̼� �ð�
    public int jumpCount = 1;         // ���� Ƚ��
    public int deathCount = 3;

    private bool isJumping = false;   // ���� �� ����
    private MapCreator mapCreator;

    [SerializeField]
    private Animator animator;

    private void Start()
    {
        mapCreator = FindObjectOfType<MapCreator>();
        animator = GetComponentInChildren<Animator>();
    }

    // ȭ��ǥ �Է�
    public void OnArrows(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            Vector2 input = context.ReadValue<Vector2>();
            TryMove(input);
        }
    }

    // WASD �Է�
    public void OnWASD(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            Vector2 input = context.ReadValue<Vector2>();
            TryMove(input);
        }
    }

    private void TryMove(Vector2 input)
    {
        if (input == Vector2.zero) return;
        if (isJumping) return;

        // �¿� �̵�
        if (input.x != 0)
        {
            Vector3 direction = new Vector3(input.x, 0, 0);

            if (CanMove(direction, 1f))
            {
                MoveSide(input.x);
            }
        }

        // ������ �̵�
        if (input.y > 0)
        {
            Vector3 direction = Vector3.forward;

            if (CanMove(direction, 2f))
            {
                JumpInPlace();
                mapCreator.DestroyAndCreateTile();
            }
        }

        // �ڷ� �̵�
        else if (input.y < 0)
        {
            Vector3 direction = Vector3.back;

            if (CanMove(direction, 2f))
            {
                JumpInPlace();
                mapCreator.ReverseDestroyAndCreateTile();
                deathCount--;
                if (deathCount <= 0)
                {
                    FindObjectOfType<PlayerDieSystem>().PlayerDie();
                }
            }
        }
    }

    // �¿� �̵�
    private void MoveSide(float xInput)
    {
        Vector3 moveOffset = new Vector3(xInput * 1f, 0, 0);
        Vector3 targetPos = transform.position + moveOffset;

        isJumping = true;
        animator.SetBool("IsJumping", true); // ���� ���� ��

        transform.DOJump(targetPos, jumpPower, jumpCount, duration)
            .OnComplete(() =>
            {
                isJumping = false;
                animator.SetBool("IsJumping", false); // ���� ������
            });
    }

    // ���ڸ� ����
    private void JumpInPlace()
    {
        isJumping = true;
        animator.SetBool("IsJumping", true); // ���� ���� ��

        transform.DOJump(transform.position, jumpPower, jumpCount, duration)
            .OnComplete(() =>
            {
                isJumping = false;
                animator.SetBool("IsJumping", false); // ���� ������
            });
    }

    // �̵� ���� ���� üũ
    private bool CanMove(Vector3 direction, float distance)
    {
        Ray ray = new Ray(transform.position + Vector3.up * 0.5f, direction);
        RaycastHit hit;

        if (Physics.Raycast(ray, out hit, distance))
        {
            if (hit.collider.CompareTag("Objects"))
            {
                return false;
            }
        }
        return true;
    }
}
